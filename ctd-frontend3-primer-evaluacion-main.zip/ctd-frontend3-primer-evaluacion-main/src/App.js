import Layout from "./components/Layout/Layout";

function App() {
  return (
    <div className="App">
      <Layout limiteHistorias={5}/>
    </div>
  );
}

export default App;
